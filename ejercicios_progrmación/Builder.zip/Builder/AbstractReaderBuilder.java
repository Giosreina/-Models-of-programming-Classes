import java.io.*;

// Clase abstracta AbstractBuilder
abstract class AbstractReaderBuilder {
    protected BufferedReader bufferedReader;

    // Método abstracto para construir el reader
    public abstract void buildReader();

    // Método para obtener el reader construido
    public BufferedReader getReader() {
        return bufferedReader;
    }
}