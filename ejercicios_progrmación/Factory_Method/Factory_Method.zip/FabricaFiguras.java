import java.io.IOException;
public abstract class FabricaFiguras {
    public abstract Figura crearFigura() throws IOException;
}