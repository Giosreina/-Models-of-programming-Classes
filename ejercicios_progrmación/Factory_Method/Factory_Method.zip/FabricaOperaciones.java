public abstract class FabricaOperaciones{
    public abstract Operaciones crearOperaciones();
}