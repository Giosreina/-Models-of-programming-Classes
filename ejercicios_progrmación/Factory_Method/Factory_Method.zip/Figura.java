public abstract class Figura {
    public abstract double CalcularArea();
}
