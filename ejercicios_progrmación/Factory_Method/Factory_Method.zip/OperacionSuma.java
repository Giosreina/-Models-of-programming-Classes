public class OperacionSuma extends Operaciones {
    public double Operar(double a, double b) {
        return a + b;
    }
}