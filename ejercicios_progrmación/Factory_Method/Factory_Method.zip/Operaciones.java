public abstract class Operaciones{
    public abstract double Operar(double Operador1, double Operador2);
}